<script setup>
// 根组件 - 路由视图容器
</script>

<template>
  <router-view />
</template>

<style>
#app {
  width: 100%;
  height: 100vh;
}
</style>
